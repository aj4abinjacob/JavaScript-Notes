function randompickerbtn() {
  
}

function hexFindbtn() {
}

function RGBFindbtn() {
  
}

function RangeSelector() {
  
}

// hex to rgb converter

String.prototype.convertToRGB = function () {
  
};

function hexConvbtn() {
  
}

function rgbConvbtn() {
  
}
